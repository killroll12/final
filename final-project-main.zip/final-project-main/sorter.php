<?php
include "config.php";


$seat_checker="SELECT department_id,max_num_of_seats FROM deparment";
$gpasorter="SELECT student_id,totalall from student_report ORDERBY totalall";
$student_identifier="SELECT * FROM placement_report where student_report='$gpasorter'";
$seat_checker_shower=mysqli_fetch_all($seat_checker());

$student_ident=mysqli_fetch($student_identifier);








if($student_ident ==0){
    $number_of_students= 0;
    $max_seats=$max_mum_of_seats;
}
elseif($student_ident<$max_mum_of_seats){
    $firtplace=mysqli_query("SELECT INTO ");
    $student_ident=$student_ident-1;
    $max_mum_of_seats=$max_mum_of_seats -1;

}
else{
echo "error";
}