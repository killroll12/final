import cgitb 
import cx_Oracle
cgitb.enable()
import cgi