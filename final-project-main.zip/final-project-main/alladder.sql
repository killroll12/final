use project;

update users set gpa_out_of_85=(gpa*85/4),five=0,total=gpa_out_of_85*4/100, totalall=gpa_out_of_85 where not(gender='female') and not(region='female')and not(health_status='disabled');

update users set gpa_out_of_85=(gpa*85/4),five=5*gpa_out_of_85/85,total= 3*five*4/100 + gpa_out_of_85*4/100,totalall=3*five + gpa_out_of_85 where gender='female' and region='oromia' and health_status='disabled';

update users set gpa_out_of_85=(gpa*85/4),five=5*gpa_out_of_85/85 ,total=2*five*4/100 + gpa_out_of_85*4/5*100 ,totalall=2*five + gpa_out_of_85 where (gender='female' and region='oromia')or (gender='female' and health_status='disabled') or (region='oromia' and health_status='disabled');

update users set gpa_out_of_85=(gpa*85/4),five=5*gpa_out_of_85/85 , total=five*4/100,totalall=five + gpa_out_of_85 where gender='female' or region='oromia' or health_status='disabled';


alter table users drop column total;
select * from users;