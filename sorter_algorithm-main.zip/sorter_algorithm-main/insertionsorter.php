<?php

 function insertion_Sort($my_array)
{
	for($i=0;$i<count($my_array);$i++){
		$val = $my_array[$i];
		$j = $i-1;
		while($j>=0 && $my_array[$j] > $val){
			$my_array[$j+1] = $my_array[$j];
			$j--;
		}
		$my_array[$j+1] = $val;
	}
return $my_array;
}
$test_array = array(3, 0, 2, 5, -1, 4, 1);
echo "Original Array :\n";
echo implode(', ',$test_array );
echo "\nSorted Array :\nr";
print_r(insertion_Sort($test_array));
?>
/*
this one is for the retrival as an array with


$result = mysql_query('SELECT id, department, createddate, status FROM demo');
$new_array = array();

while($row = mysql_fetch_assoc($result)) {
    $department = $row['department'];

    // To add enter result row including deparment
    $new_array[$department] = $row; 

    // OR to have only id, createdate, status
    $new_array[$department] = 
             array('id' => $row['id'], 
                   'createdate' => $row['createdate'],
                   'status' => $row['status']);

}
*/




/**
 Example #1 Query with aliased duplicate field names

SELECT table1.field AS foo, table2.field AS bar FROM table1, table2
Example #2 mysql_fetch_array() with MYSQL_NUM
*/

/*
mysql_connect("localhost", "mysql_user", "mysql_password") or
    die("Could not connect: " . mysql_error());
mysql_select_db("mydb");

$result = mysql_query("SELECT id, name FROM mytable");

while ($row = mysql_fetch_array($result, MYSQL_NUM)) {
    printf("ID: %s  Name: %s", $row[0], $row[1]);  
}

mysql_free_result($result);

*/
Example #3 mysql_fetch_array() with MYSQL_ASSOC
/*

mysql_connect("localhost", "mysql_user", "mysql_password") or
    die("Could not connect: " . mysql_error());
mysql_select_db("mydb");

$result = mysql_query("SELECT id, name FROM mytable");

while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    printf("ID: %s  Name: %s", $row["id"], $row["name"]);
}

mysql_free_result($result);

Example #4 mysql_fetch_array() with MYSQL_BOTH
*/
/*

mysql_connect("localhost", "mysql_user", "mysql_password") or
    die("Could not connect: " . mysql_error());
mysql_select_db("mydb");

$result = mysql_query("SELECT id, name FROM mytable");

while ($row = mysql_fetch_array($result, MYSQL_BOTH)) {
    printf ("ID: %s  Name: %s", $row[0], $row["name"]);
}

mysql_free_result($result);



*/


/**this one is for the bubble sort using php.ini


// function for bubble sort
function bubblesort(&$Array, $n) {
  $temp;
  for($i=0; $i<$n; $i++) {
    for($j=0; $j<$n-$i-1; $j++) {
      if($Array[$j]>$Array[$j+1]) {
        $temp = $Array[$j];
        $Array[$j] = $Array[$j+1];
        $Array[$j+1] = $temp;
      }
    }
  }
}

// function to print array
function PrintArray($Array, $n) { 
  for ($i = 0; $i < $n; $i++) 
    echo $Array[$i]." ";
  echo "\n"; 
} 

// test the code
$MyArray = array(1, 10, 23, 50, 4, 9, -4);
$n = sizeof($MyArray); 
echo "Original Array\n";
PrintArray($MyArray, $n);

bubblesort($MyArray, $n);
echo "\nSorted Array\n";
PrintArray($MyArray, $n);
?>





*/



/**this si the algorithm for merge sorting using php's array



// function for merge sort - splits the array 
// and call merge function to sort and merge the array
// mergesort is a recursive function
function mergesort(&$Array, $left, $right) {
  if ($left < $right) { 
    $mid = $left + (int)(($right - $left)/2);
    mergesort($Array, $left, $mid);
    mergesort($Array, $mid+1, $right);
    merge($Array, $left, $mid, $right);
  }
}

// merge function performs sort and merge operations
// for mergesort function
function merge(&$Array, $left, $mid, $right) {
  // Create two temporary array to hold split 
  // elements of main array 
  $n1 = $mid - $left + 1; //no of elements in LeftArray
  $n2 = $right - $mid;     //no of elements in RightArray    
  $LeftArray = array_fill(0, $n1, 0); 
  $RightArray = array_fill(0, $n2, 0);
  for($i=0; $i < $n1; $i++) { 
    $LeftArray[$i] = $Array[$left + $i];
  }
  for($i=0; $i < $n2; $i++) { 
    $RightArray[$i] = $Array[$mid + $i + 1];
  }

  // In below section x, y and z represents index number
  // of LeftArray, RightArray and Array respectively
  $x=0; $y=0; $z=$left;
  while($x < $n1 && $y < $n2) {
    if($LeftArray[$x] < $RightArray[$y]) { 
      $Array[$z] = $LeftArray[$x]; 
      $x++; 
    }
    else { 
      $Array[$z] = $RightArray[$y];  
      $y++; 
    }
    $z++;
  }

  // Copying the remaining elements of LeftArray
  while($x < $n1) { 
     $Array[$z] = $LeftArray[$x];  
     $x++;  
     $z++;
  }

  // Copying the remaining elements of RightArray
  while($y < $n2) { 
    $Array[$z] = $RightArray[$y]; 
    $y++;  
    $z++; 
  }
}

// function to print array
function PrintArray($Array, $n) { 
  for ($i = 0; $i < $n; $i++) 
    echo $Array[$i]." "; 
  echo "\n";
} 

// test the code
$MyArray = array(10, 1, 23, 50, 4, 9, -4);
$n = sizeof($MyArray); 
echo "Original Array\n";
PrintArray($MyArray, $n);

mergesort($MyArray, 0, $n-1);
echo "\nSorted Array\n";
PrintArray($MyArray, $n);
?>





*/