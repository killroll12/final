<?php
include "connectioner.php";


$qry1 = "SELECT * FROM placement_report order by totalall DESC";
$con2 = mysqli_query($conn, $qry1);


$con3 = mysqli_fetch_assoc($con2);
while ($con3) {
    if ($con3) {
        mysqli_connect_error();
    }
    switch ($_POST['choice1']) {
        case 'choice1':
            $first1deleter="DELETE * from posts where student_id in (select student_id from placement_result count(INDEX)>1);";
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=1  order by totalall DESC LIMIT '$mx_seats1'";

            $frist_switch1 = mysqli_query($conn, $qry2);
            $first_switch_reslut1 = mysqli_fetch_assoc($frist_switch1);
            $first_switch_result1_arrayer=mysqli_fetch_array($conn,$frist_switch1);
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=1 order by totalall DESC limit 'mx_seats2'";
            $frist_switch2 = mysqli_query($conn, $qry3);
            $first_switch_reslut2 = mysqli_fetch_assoc($frist_switch2);
            $first_switch_result2_arrayer=mysqli_fetch_array($conn,$frist_switch2);
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=1 order by totalall DESC limit 'mx_seats3'";
            $frist_switch3 = mysqli_query($conn, $qry4);
            $first_switch_reslut3 = mysqli_fetch_assoc($frist_switch3);
            $first_switch_result3_arrayer=mysqli_fetch_array($conn,$frist_switch3);
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=1 order by totalall DESC limit 'mx_seats4'";
            $first_switch4=mysqli_query($conn,$qry5);
            $first_switch_result4=mysqli_fetch_assoc($first_switch4);
            $first_switch4_result4=mysqli_fetch_assoc($conn,$first_switch4);
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=1 order by totalall DESC limit 'mx_seats5'";
           $first_switch5=mysqli_query($conn,$qry6);
           $first_switch5_result=mysqli_fetch_assoc($conn, $first_switch5);
           $first_switch_result5_arrayer=mysqli_fetch_array($conn,$frist_switch5);
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=1 order by totalall DESC limit 'mx_seats6'";
           
            $first_switch6=mysqli_query($conn,$qry6);
            $first_switch6_result=mysqli_fetch_assoc($conn, $first_switch6);
            $first_switch_result6_arrayer=mysqli_fetch_array($conn,$frist_switch6);
           
           
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=1 order by totalall DESC limit 'mx_seats7'";
            
            $first_switch7=mysqli_query($conn,$qry8);
            $first_switch7_result=mysqli_fetch_assoc($conn,$first_switch7);
            $first_switch_result7_arrayer=mysqli_fetch_array($conn,$first_switch7);
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=1 order by totalall DESC limit 'mx_seats8'";
            
            $first_switch8=mysqli_query($conn, $qry9);
            $first_switch8_result=mysqli_fetch_assoc($conn,$qry9);
            $first_switch_result8_arrayer=mysqli_fetch_array($conn,$qry9);

            
            
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=1 order by totalall DESC limit 'mx_seats9'";
           
           
           $frist_switch9=mysqli_query($conn,$qry10);
           $first_switch9_result=mysqli_fetch_assoc($conn,$frist_switch9);
           
           $first_switch_result9_arrayer=mysqli_fetch_array($conn,$first_switch9);
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=1 order by totalall DESC limit 'mx_seats10'";
            
            $frist_switch10=mysqli_query($conn,$qry10);
           $first_switch10_result=mysqli_fetch_assoc($conn,$frist_switch10);
           
           $first_switch_result10_arrayer=mysqli_fetch_array($conn,$first_switch10);
            
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=1 order by totalall DESC limit 'mx_seats11'";
            
            $frist_switch11=mysqli_query($conn,$qry12);
           $first_switch11_result=mysqli_fetch_assoc($conn,$frist_switch12);
           
           $first_switch_result11_arrayer=mysqli_fetch_array($conn,$first_switch12);
            
            
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=1 order by totalall DESC limit 'mx_seats12'";
            
            $frist_switch12=mysqli_query($conn,$qry13);
           $first_switch12_result=mysqli_fetch_assoc($conn,$frist_switch12);
           
           $first_switch_result12_arrayer=mysqli_fetch_array($conn,$first_switch13);
            
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=1 order by totalall DESC limit 'mx_seats13'";
            
            $frist_switch13=mysqli_query($conn,$qry14);
           $first_switch13_result=mysqli_fetch_assoc($conn,$frist_switch13);
           
           $first_switch_result13_arrayer=mysqli_fetch_array($conn,$first_switch13);
            
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=1 order by totalall DESC limit 'mx_seats14'";
            
            
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=1 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice2']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=2  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=2 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=2 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=2 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=2 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=2 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=2 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=2 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=2 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=2 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=2 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=2 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=2 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=2 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=2 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice3']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=3  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=3 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=3 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=3 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=3 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=3 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=3 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=3 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=3 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=3 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=3 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=3 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=3 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=3 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=3 order by totalall DESC limit 'mx_seats15'";
            break;
    }


    switch ($_POST['choice4']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=4  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=4 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=4 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=4 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=4 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=4 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=4 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=4 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=4 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=4 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=4 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=4 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=4 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=4 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=4 order by totalall DESC limit 'mx_seats15'";
            break;
    }



    switch ($_POST['choice5']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=5  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=5 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=5 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=5 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=5 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=5 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=5 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=5 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=5 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=5 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=5 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=5 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=5 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=5 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=5 order by totalall DESC limit 'mx_seats15'";
            break;
    }

    switch ($_POST['choice6']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=6  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=6 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=6 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=6 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=6 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=6 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=6 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=6 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=6 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=6 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=6 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=6 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=6 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=6 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=6 order by totalall DESC limit 'mx_seats15'";
            break;
    }

    switch ($_POST['choice7']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=7  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=7 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=7 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=7 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=7 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=7 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=7 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=7 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=7 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=7 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=7 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=7 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=7 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=7 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=7 order by totalall DESC limit 'mx_seats15'";
            break;
    }

    switch ($_POST['choice8']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=8  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=8 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=8 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=8 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=8 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=8 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=8 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=8 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=8 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=8 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=8 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=8 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=8 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=8 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=8 order by totalall DESC limit 'mx_seats15'";
            break;
    }



    switch ($_POST['choice9']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=9  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=9 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=9 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=9 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=9 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=9 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=9 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=9 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=9 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=9 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=9 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=9 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=9 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=9 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=9 order by totalall DESC limit 'mx_seats15'";
            break;
    }


    switch ($_POST['choice10']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1= 10 order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=10 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=10 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=10 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=10 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=10 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=10 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=10 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=10 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=10 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=10 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=10 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=10 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=10 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=10 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice11']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=11  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=11 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=11 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=11 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=11 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=11 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=11 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=11 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=11 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=11 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=11 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=11 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=11 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=11 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=11 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice12']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=12  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=12 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=12 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=12 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=12 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=12 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=12 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=12 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=12 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=12 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=12 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=12 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=12 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=12 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=12 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice13']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=13  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=13 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=13 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=13 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=13 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=13 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=13 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=13 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=13 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=13 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=13 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=13 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=13 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=13 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=13 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice14']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=14  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=14 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=14 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=14 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=14 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=14 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=14 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=14 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=14 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=14 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=14 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=14 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=14 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=14 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=14 order by totalall DESC limit 'mx_seats15'";
            break;
    }
    switch ($_POST['choice15']) {
        case 'choice1':
            $qry2 = "INSERT INTO placement_result(student_id,department_id) SELECT student_ID,choice1 FROM placement_report where choice1=15  order by totalall DESC LIMIT '$mx_seats1'";
            break;
        case 'choice2':
            $qry3 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice2 from placement_report where choice2=15 order by totalall DESC limit 'mx_seats2'";
            break;
        case 'choice3':
            $qry4 = "INSERT INTO placement_result(student_id,department_id)select student_ID,choice3 from placement_report where choice3=15 order by totalall DESC limit 'mx_seats3'";
            break;
        case 'choice4':
            $qry5 = "INSERT INTO placement_result(student_id,deparment_id) select student_ID,choice4 from placement_report where choice4=15 order by totalall DESC limit 'mx_seats4'";
            break;
        case 'choice5':
            $qry6 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice5 from placement_report where choice5=15 order by totalall DESC limit 'mx_seats5'";
            break;
        case 'choice6':
            $qry7 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice6 from placement_report where choice6=15 order by totalall DESC limit 'mx_seats6'";
            break;
        case 'choice7':
            $qry8 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice7 from placement_report where choice7=15 order by totalall DESC limit 'mx_seats7'";
            break;
        case 'choice8':
            $qry9 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice8 from placement_report where choice8=15 order by totalall DESC limit 'mx_seats8'";
            break;
        case 'choice9':
            $qry10 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice9 from placement_report where choice9=15 order by totalall DESC limit 'mx_seats9'";
            break;
        case 'choice10':
            $qry11 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice10 from placement_report where choice10=15 order by totalall DESC limit 'mx_seats10'";
            break;
        case 'choice11':
            $qry12 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice11 from placement_report where choice11=15 order by totalall DESC limit 'mx_seats11'";
            break;
        case 'choice12':
            $qry13 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice12 from placement_report where choice12=15 order by totalall DESC limit 'mx_seats12'";
            break;
        case 'choice13':
            $qry14 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice13 from placement_report where choice13=15 order by totalall DESC limit 'mx_seats13'";
            break;
        case 'choice14':
            $qry15 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice14 from placement_report where choice14=15 order by totalall DESC limit 'mx_seats14'";
            break;
        case 'choice15':
            $qry16 = "INSERT INTO placement_result(student_id,department_id) select student_ID,choice15 from placement_report where choice15=15 order by totalall DESC limit 'mx_seats15'";
            break;
    }
}
