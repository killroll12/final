
delete * from posts where id=(select student_id from placement_result count(INDEX)>1);




delete * from posts where student_id in (select student_id from placement_result count(INDEX)>1);


---for the triggers part for checking and stopping the insertion of the new data into the database'

--"
--*"--
create trigger oneers
BEFORE insert on users
for each row
begin
DECLARE cnt int;
select count(*) into cnt from_yout_table_name;
if cnt = 10 THEN
signal sqlstate '45000' set message_text='you can store only 10';
end if;
end;